public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
public class ContaBancaria {
    public int numeroDaConta;
    public double saldo;
    public String titular;

    public ContaBancaria(int numeroDaConta, String titular) {
        this.numeroDaConta = numeroDaConta;
        this.titular = titular;
    }

    public void depositar(double valor) {
        saldo += valor;
        System.out.println("Depósito de R$" + valor + " realizado com sucesso. Novo saldo: R$" + saldo);
    }

    public void sacar(double valor) {
        if (saldo < valor) {
            System.out.println("Saldo insuficiente para realizar o saque.");
        } else {
            saldo -= valor;
            System.out.println("Saque de R$" + valor + " realizado com sucesso. Novo saldo: R$" + saldo);
        }
    }

    public void transferir(double valor, ContaBancaria contaDestino) {
        if (saldo < valor) {
            System.out.println("Saldo insuficiente para realizar a transferência.");
        } else {
            saldo -= valor;
            contaDestino.saldo += valor;
            System.out.println("Transferência de R$" + valor + " realizada com sucesso para a conta de " + contaDestino.titular + ". Novo saldo da conta de origem: R$" + saldo + ". Novo saldo da conta de destino: R$" + contaDestino.saldo);
        }
    }
}

    ContaBancaria conta1 = new ContaBancaria(123, "João");
    ContaBancaria conta2 = new ContaBancaria(456, "Maria");

conta1.depositar(1000.0);
        conta1.sacar(500.0);
        conta1.transferir(200.0, conta2);

        
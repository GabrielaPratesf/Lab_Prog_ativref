public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
public class Calculadora {

    public int somar(int a, int b) {
        return a + b;
    }

    public int subtrair(int a, int b) {
        return a - b;
    }

    public int multiplicar(int a, int b) {
        return a * b;
    }

    public double dividir(double a, double b) {
        return a / b;
    }
}

    Calculadora calculadora = new Calculadora();
    int resultadoSoma = calculadora.somar(10, 5);
    int resultadoSubtracao = calculadora.subtrair(10, 5);
    int resultadoMultiplicacao = calculadora.multiplicar(10, 5);
    double resultadoDivisao = calculadora.dividir(10.0, 5.0);

System.out.println("Resultado da soma: " + resultadoSoma); // Saída: Resultado da soma: 15
        System.out.println("Resultado da subtração: " + resultadoSubtracao); // Saída: Resultado da subtração: 5
        System.out.println("Resultado da multiplicação: " + resultadoMultiplicacao); // Saída: Resultado da multiplicação: 50
        System.out.println("Resultado da divisão: " + resultadoDivisao); // Saída: Resultado da divisão: 2.0

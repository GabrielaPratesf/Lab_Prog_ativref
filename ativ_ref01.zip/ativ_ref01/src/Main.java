public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

public class Carro {
    public String marca;
    public String modelo;
    public int ano;
    public String cor;

    public void acelerar() {
        System.out.println("Acelerando o carro!");
    }

    public void frear() {
        System.out.println("Freando o carro!");
    }
}

    Carro carro = new Carro();
carro.marca = "Toyota";
        carro.modelo = "Corolla";
        carro.ano = 2022;
        carro.cor = "Preto";

        carro.acelerar();
        carro.frear();
